"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

import { toggleProductStatus } from "@/actions/product";

export default function ProductStatusToggle({
  locale,
  id,
  status,
}: {
  locale: string;
  id: string;
  status: "active" | "inactive";
}) {
  const tc = useTranslations("common");
  const router = useRouter();

  const [isPending, startTransition] =
    useTransition();

  function handleToggle() {
    startTransition(async () => {
      await toggleProductStatus(
        locale,
        id,
        status === "active"
          ? "inactive"
          : "active"
      );

      router.refresh();
    });
  }

  return (
    <button
      type="button"
      onClick={handleToggle}
      disabled={isPending}
      className={`text-xs px-2.5 py-1 rounded-full ${
        status === "active"
          ? "bg-green-50 text-green-600 hover:bg-green-100"
          : "bg-neutral-100 text-neutral-500 hover:bg-neutral-200"
      } disabled:opacity-50`}
    >
      {isPending
        ? "..."
        : status === "active"
        ? tc("active")
        : tc("inactive")}
    </button>
  );
}