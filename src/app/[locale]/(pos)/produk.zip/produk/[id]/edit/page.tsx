"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

import {
  createProduct,
  updateProduct,
} from "@/actions/product";

type Category = {
  id: string;
  name: string;
};

type ProductData = {
  id: string;
  name: string;
  categoryId: string;
  unit: string;
  price: number;
  stock: number;
  barcode: string | null;
  expiredDate: Date | null;
  description: string | null;
  imageUrl: string | null;
};

export default function ProductForm({
  locale,
  categories,
  product,
}: {
  locale: string;
  categories: Category[];
  product?: ProductData;
}) {
  const t = useTranslations("produk");
  const tc = useTranslations("common");

  const router = useRouter();

  const [isPending, startTransition] =
    useTransition();

  const [imageUrl, setImageUrl] = useState(
    product?.imageUrl ?? ""
  );

  const expiredDefault = product?.expiredDate
    ? new Date(product.expiredDate)
        .toISOString()
        .slice(0, 10)
    : "";

  function handleSubmit(
    e: React.FormEvent<HTMLFormElement>
  ) {
    e.preventDefault();

    const fd = new FormData(e.currentTarget);

    const input = {
      name: String(fd.get("name") || ""),
      categoryId: String(
        fd.get("categoryId") || ""
      ),
      unit: fd.get("unit") as never,
      price: Number(fd.get("price") || 0),

      // Stock hanya diisi ketika tambah.
      stock: product
        ? product.stock
        : Number(fd.get("stock") || 0),

      barcode: String(fd.get("barcode") || ""),
      expiredDate: String(
        fd.get("expiredDate") || ""
      ),
      description: String(
        fd.get("description") || ""
      ),
      imageUrl: String(
        fd.get("imageUrl") || ""
      ),
    };

    startTransition(async () => {
      if (product) {
        await updateProduct(
          locale,
          product.id,
          input
        );
      } else {
        await createProduct(
          locale,
          input
        );
      }

      router.push(`/${locale}/produk`);
      router.refresh();
    });
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-4"
    >
      {/* IMAGE */}
      <Field label={t("imageUrl")}>
        <div className="flex items-center gap-4">
          <div className="h-20 w-20 rounded-lg bg-neutral-100 border border-neutral-200 overflow-hidden shrink-0 flex items-center justify-center text-neutral-300 text-2xl">
            {imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={imageUrl}
                alt=""
                className="h-full w-full object-cover"
                onError={(e) => {
                  e.currentTarget.style.display =
                    "none";
                }}
              />
            ) : (
              "🖼"
            )}
          </div>

          <input
            name="imageUrl"
            value={imageUrl}
            onChange={(e) =>
              setImageUrl(e.target.value)
            }
            placeholder="https://..."
            className="input flex-1"
          />
        </div>

        <p className="text-xs text-neutral-400 mt-1">
          {t("imageUrlNote")}
        </p>
      </Field>

      {/* BASIC DATA */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label={t("name")}>
          <input
            name="name"
            required
            defaultValue={product?.name}
            className="input"
          />
        </Field>

        <Field label={t("category")}>
          <select
            name="categoryId"
            required
            defaultValue={product?.categoryId}
            className="input"
          >
            <option value="">
              Pilih kategori
            </option>

            {categories.map((category) => (
              <option
                key={category.id}
                value={category.id}
              >
                {category.name}
              </option>
            ))}
          </select>
        </Field>

        <Field label={t("unit")}>
          <select
            name="unit"
            required
            defaultValue={
              product?.unit ?? "pack"
            }
            className="input"
          >
            <option value="pack">
              {t("unitPack")}
            </option>

            <option value="box">
              {t("unitBox")}
            </option>

            <option value="renceng">
              {t("unitRenceng")}
            </option>

            <option value="pcs">
              {t("unitPcs")}
            </option>
          </select>
        </Field>

        <Field label={t("price")}>
          <input
            name="price"
            type="number"
            min={0}
            required
            defaultValue={product?.price}
            className="input"
          />
        </Field>

        {/* STOCK HANYA SAAT TAMBAH */}
        {!product && (
          <Field label={t("stock")}>
            <input
              name="stock"
              type="number"
              min={0}
              required
              defaultValue={0}
              className="input"
            />

            <p className="text-xs text-neutral-400 mt-1">
              Stok awal produk.
            </p>
          </Field>
        )}

        <Field label={t("barcode")}>
          <input
            name="barcode"
            defaultValue={
              product?.barcode ?? ""
            }
            className="input"
          />
        </Field>

        <Field label={t("expiredDate")}>
          <input
            name="expiredDate"
            type="date"
            defaultValue={expiredDefault}
            className="input"
          />
        </Field>
      </div>

      {/* DESCRIPTION */}
      <Field label={t("description")}>
        <textarea
          name="description"
          rows={3}
          defaultValue={
            product?.description ?? ""
          }
          className="input resize-none"
        />
      </Field>

      {/* BUTTON */}
      <div className="flex gap-3 pt-2">
        <button
          type="submit"
          disabled={isPending}
          className="bg-primary-700 text-white text-sm px-5 py-2.5 rounded-lg font-medium disabled:opacity-50"
        >
          {isPending
            ? "Menyimpan..."
            : tc("save")}
        </button>

        <button
          type="button"
          onClick={() => router.back()}
          disabled={isPending}
          className="border border-neutral-200 text-sm px-5 py-2.5 rounded-lg font-medium hover:bg-neutral-50 disabled:opacity-50"
        >
          {tc("cancel")}
        </button>
      </div>

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid #e2e8f0;
          border-radius: 0.5rem;
          padding: 0.55rem 0.75rem;
          font-size: 0.875rem;
          background: white;
          outline: none;
        }

        .input:focus {
          border-color: #64748b;
        }
      `}</style>
    </form>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="text-sm font-medium text-neutral-700 block mb-1.5">
        {label}
      </label>

      {children}
    </div>
  );
}