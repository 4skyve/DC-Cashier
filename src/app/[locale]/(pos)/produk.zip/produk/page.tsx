import Link from "next/link";
import { redirect } from "next/navigation";
import { getTranslations } from "next-intl/server";

import { getAllProducts, getCategories } from "@/actions/product";
import { getSession } from "@/lib/auth";

import ProductStatusToggle from "./ProductStatusToggle";
import SortSelect from "./SortSelect";

export default async function ProdukPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{
    q?: string;
    category?: string;
    sort?: string;
    page?: string;
  }>;
}) {
  const { locale } = await params;
  const { q, category, sort, page } = await searchParams;

  const session = await getSession();

  if (!session) {
    redirect(`/${locale}/login`);
  }

  const isAdmin = session.role === "admin";

  const t = await getTranslations({
    locale,
    namespace: "produk",
  });

  const tc = await getTranslations({
    locale,
    namespace: "common",
  });

  const [result, categories] = await Promise.all([
    getAllProducts({
      q,
      categoryId: category,
      sort,
      page: Number(page) || 1,
    }),
    getCategories(),
  ]);

  const sortOptions = [
    {
      value: "createdAt-desc",
      label: t("sortNewest"),
    },
    {
      value: "name-asc",
      label: t("sortNameAsc"),
    },
    {
      value: "price-asc",
      label: t("sortPriceAsc"),
    },
    {
      value: "price-desc",
      label: t("sortPriceDesc"),
    },
    {
      value: "stock-asc",
      label: t("sortStockAsc"),
    },
  ];

  function buildQuery(
    overrides: Record<string, string | undefined>
  ) {
    const params = new URLSearchParams();

    const merged = {
      q,
      category,
      sort,
      ...overrides,
    };

    Object.entries(merged).forEach(([key, value]) => {
      if (value) {
        params.set(key, value);
      }
    });

    const query = params.toString();

    return query ? `?${query}` : "";
  }

  return (
    <div className="space-y-4">
      {/* HEADER */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold text-primary-700">
            {t("title")}
          </h1>

          <p className="text-sm text-neutral-400 mt-1">
            {isAdmin
              ? "Kelola produk dan stok"
              : "Lihat produk dan informasi stok"}
          </p>
        </div>

        {isAdmin && (
          <Link
            href={`/${locale}/produk/baru`}
            className="bg-primary-700 text-white text-sm px-4 py-2 rounded-lg font-medium hover:bg-primary-800"
          >
            + {t("addProduct")}
          </Link>
        )}
      </div>

      {/* CATEGORY + SORT */}
      <div className="flex flex-wrap gap-2">
        <a
          href={buildQuery({
            category: undefined,
            page: undefined,
          })}
          className={`text-sm px-3 py-1.5 rounded-full border ${
            !category
              ? "bg-primary-700 text-white border-primary-700"
              : "border-neutral-200 text-neutral-600"
          }`}
        >
          {t("allCategories")}
        </a>

        {categories.map((c) => (
          <a
            key={c.id}
            href={buildQuery({
              category: c.id,
              page: undefined,
            })}
            className={`text-sm px-3 py-1.5 rounded-full border ${
              category === c.id
                ? "bg-primary-700 text-white border-primary-700"
                : "border-neutral-200 text-neutral-600"
            }`}
          >
            {c.name}
          </a>
        ))}

        <div className="ml-auto">
          <form method="get" className="flex items-center gap-2">
            {category && (
              <input
                type="hidden"
                name="category"
                value={category}
              />
            )}

            {q && (
              <input
                type="hidden"
                name="q"
                value={q}
              />
            )}

          <SortSelect
            defaultValue={sort ?? "createdAt-desc"}
            options={sortOptions}
          />
          </form>
        </div>
      </div>

      {/* PRODUCT TABLE */}
      <div className="bg-white border border-neutral-200 rounded-xl overflow-x-auto">
        <table className="w-full text-sm min-w-[760px]">
          <thead className="bg-neutral-50 text-neutral-500 text-left">
            <tr>
              <th className="px-4 py-3 font-medium">
                {t("name")}
              </th>

              <th className="px-4 py-3 font-medium">
                {t("category")}
              </th>

              <th className="px-4 py-3 font-medium">
                {t("unit")}
              </th>

              <th className="px-4 py-3 font-medium">
                {t("price")}
              </th>

              <th className="px-4 py-3 font-medium">
                {t("stock")}
              </th>

              <th className="px-4 py-3 font-medium">
                {tc("status")}
              </th>

              <th className="px-4 py-3 font-medium">
                {tc("actions")}
              </th>
            </tr>
          </thead>

          <tbody>
            {result.items.length === 0 && (
              <tr>
                <td
                  colSpan={7}
                  className="px-4 py-8 text-center text-neutral-400"
                >
                  {tc("empty")}
                </td>
              </tr>
            )}

            {result.items.map((p) => (
              <tr
                key={p.id}
                className="border-t border-neutral-100 hover:bg-neutral-50/50"
              >
                {/* NAME */}
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-neutral-100 overflow-hidden shrink-0 flex items-center justify-center">
                      {p.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={p.imageUrl}
                          alt={p.name}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <span className="text-neutral-300">
                          🖼
                        </span>
                      )}
                    </div>

                    <span className="font-medium text-primary-800">
                      {p.name}
                    </span>
                  </div>
                </td>

                {/* CATEGORY */}
                <td className="px-4 py-3 text-neutral-500">
                  {p.category.name}
                </td>

                {/* UNIT */}
                <td className="px-4 py-3 text-neutral-500 capitalize">
                  {p.unit}
                </td>

                {/* PRICE */}
                <td className="px-4 py-3">
                  {tc("currencyPrefix")}{" "}
                  {p.price.toLocaleString("id-ID")}
                </td>

                {/* STOCK */}
                <td className="px-4 py-3">
                  <span
                    className={
                      p.stock <= 0
                        ? "text-red-500 font-medium"
                        : p.stock <= 10
                        ? "text-orange-500 font-medium"
                        : "text-neutral-700"
                    }
                  >
                    {p.stock}
                  </span>
                </td>

                {/* STATUS */}
                <td className="px-4 py-3">
                  {isAdmin ? (
                  <ProductStatusToggle
                    locale={locale}
                    id={p.id}
                    status={p.status}
                  />
                  ) : (
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${
                        p.status === "active"
                          ? "bg-green-50 text-green-600"
                          : "bg-neutral-100 text-neutral-500"
                      }`}
                    >
                      {p.status === "active"
                        ? tc("active")
                        : tc("inactive")}
                    </span>
                  )}
                </td>

                {/* ACTIONS */}
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {isAdmin && (
                      <Link
                        href={`/${locale}/produk/${p.id}/edit`}
                        className="text-primary-700 font-medium hover:underline"
                      >
                        {tc("edit")}
                      </Link>
                    )}

                    <Link
                      href={`/${locale}/produk/${p.id}/stok`}
                      className="text-neutral-500 hover:text-primary-700 hover:underline"
                    >
                      {t("history")}
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* PAGINATION */}
      {result.totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          {Array.from(
            { length: result.totalPages },
            (_, i) => i + 1
          ).map((pageNumber) => (
            <a
              key={pageNumber}
              href={buildQuery({
                page: String(pageNumber),
              })}
              className={`h-8 w-8 flex items-center justify-center rounded-lg text-sm ${
                pageNumber === result.page
                  ? "bg-primary-700 text-white"
                  : "border border-neutral-200 text-neutral-500 hover:bg-neutral-50"
              }`}
            >
              {pageNumber}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}